import React from 'react'

const PromtCard = () => {
  return (
    <div>PromtCard</div>
  )
}

export default PromtCard