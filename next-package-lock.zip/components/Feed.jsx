import React from 'react'

const Feed = () => {
  return (
    <div>Feed</div>
  )
}

export default Feed